var sizeBoardSlider = document.getElementById("sizeBoardSlider");
var sizeBoardOutput = document.getElementById("sizeboardoutput");
var sizeBoardValueS = 5;
function getValueSizeBoard() {
  if (sizeBoardSlider != null) {
    // Update the current slider value (each time you drag the slider handle)
    // console.log(typeof sizeBoardOutput.getAttributeNames());
    sizeBoardSlider.oninput = function () {
    sizeBoardOutput.innerHTML = sizeBoardSlider.value; // Display the default slider value

    // sizeBoardOutput.innerHTML = this.value;
    sizeBoardValueS = parseInt(this.value);
    console.log(sizeBoardValueS);

    return sizeBoardValueS;
    };
  }
}

getValueSizeBoard();

// for (var i=0; i< sizeBoardValueS; i++) {
//   console.log("hello");
// }



// var sizeBoardValueS = document.getElementById("sizeBoardSlider").value;
// var sizeBoardValueS = parseInt(sizeBoardValueS);

// $("sizeBoardSlider").change(function(){
//    sizeBoardValueS = $(this).val();
//    // sizeBoardValueS = sizeBoardSlider.val();
//    alert(value);}
// )

var shipQuantitySlider = document.getElementById("shipQuantitySlider");
var shipQuantityOutput = document.getElementById("shipquantityoutput");
var shipQuantityValueS = 3;

function getValueShipQuantity() {
  if (shipQuantitySlider != null) {
    // sizeBoardOutput.innerHTML = sizeBoardSlider.value; // Display the default slider value
    // Update the current slider value (each time you drag the slider handle)
    shipQuantitySlider.oninput = function () {
    shipQuantityOutput.innerHTML = this.value;
    shipQuantityValueS = parseInt(this.value);
    console.log(shipQuantityValueS);

    return shipQuantityValueS;
    };
  }
}

getValueShipQuantity()

var shipSizeSlider = document.getElementById("shipSizeSlider");
var shipSizeOutput = document.getElementById("shipsizeoutput");
var shipSizeValueS = 1;
// shipSizeOutput.innerHTML = shipSizeSlider.value; // Display the default slider value

// Update the current slider value (each time you drag the slider handle)
function getValueShipSize() {
  if (shipSizeSlider != null) {
    // sizeBoardOutput.innerHTML = sizeBoardSlider.value; // Display the default slider value
    // Update the current slider value (each time you drag the slider handle)
    shipSizeSlider.oninput = function () {
    shipSizeOutput.innerHTML = this.value;
    shipSizeValueS = parseInt(this.value);
    console.log(shipSizeValueS);

    return shipSizeValueS;
    };
  }
}

getValueShipSize();

var setQuantitySlider = document.getElementById("setQuantitySlider");
var setQuantityOutput = document.getElementById("setquantityoutput");
var setQuantityValueS = 5;
// shipSizeOutput.innerHTML = shipSizeSlider.value; // Display the default slider value

// Update the current slider value (each time you drag the slider handle)
function getValueSetQuantity() {
  if (setQuantitySlider != null) {
    // sizeBoardOutput.innerHTML = sizeBoardSlider.value; // Display the default slider value
    // Update the current slider value (each time you drag the slider handle)
    setQuantitySlider.oninput = function () {
    setQuantityOutput.innerHTML = this.value;
    setQuantityValueS = parseInt(this.value);
    console.log(setQuantityValueS);

    return setQuantityValueS;
    };
  }
}

getValueSetQuantity()

// var setQuantityValue = setQuantitySlider.value;
// console.log(sizeBoardValueS);
function startGame() {
  console.log(sizeBoardValueS);
  console.log(shipQuantityValueS);
  console.log(shipSizeValueS);
  sessionStorage.setItem("sizeBoardValue", sizeBoardValueS);
  sessionStorage.setItem("shipQuantityValue", shipQuantityValueS);
  sessionStorage.setItem("shipSizeValue", shipSizeValueS);
  sessionStorage.setItem("setQuantityValue", setQuantityValueS);
}

// export {sizeBoardValueS};
