// import {sizeBoardValueS} from "./home_page_javascript";

window.onload = init;

var sizeBoardValueS = sessionStorage.getItem("sizeBoardValue");
var shipQuantityValueS = sessionStorage.getItem("shipQuantityValue");
var shipSizeValues = sessionStorage.getItem("shipSizeValue");
var setQuantityValueS = sessionStorage.getItem("setQuantityValue");

function init() {
  // Fire! button onclick handler
  var fireButton = document.getElementById("fireButton");
  fireButton.onclick = handleFireButton;

  // handle "return" key press
  var guessInput = document.getElementById("guessInput");
  guessInput.onkeypress = handleKeyPress;

  model.generateShipArray();
  // startGame();
  // console.log(sizeBoardValueS);

  generateTable(sizeBoardValueS);
  generateTableIndexes(sizeBoardValueS);
  // console.log("Table about to be generated.")
  // console.log("Table generated.")
  // place the ships on the game board
  model.generateShipLocations();
  var player1Title = document.getElementsByClassName("player1-title");
  player1Title[0].style.color = "#FF0000FF";

  var player1Score = document.getElementsByClassName("player1-score");
  player1Score[0].innerHTML = model.playerOneScore;
  var player2Score = document.getElementsByClassName("player2-score");
  player2Score[0].innerHTML = model.playerTwoScore;
  var set = document.getElementsByClassName("set");
  // set[0].innerHTML = model.currentSet;
  console.log(model.currentSet);
  if (model.currentSet === 1 && model.turns === 1 ){
    set[0].innerHTML = 1;
    model.currentSet = 1;
  }
  // var getSetNow = localStorage.getItem("setNow");
  // set[0].innerHTML = getSetNow;
  // console.log(getSetNow);

}


var model = {
    boardSize: sizeBoardValueS,
    numShips: shipQuantityValueS,
    shipLength: shipSizeValues,
    shipsSunk: 0,
    ships: [],
    playerOneScore: 0,
    playerTwoScore: 0,
    shipScore: 30,
    turns: 1,
    setQuantity: setQuantityValueS,
    currentSet: 1,

    changePlayerColor: function () {
      if (this.turns % 2 === 1) {
        var player1Title = document.getElementsByClassName("player1-title");
        var player2Title = document.getElementsByClassName("player2-title");
        player1Title[0].style.color = "#FF0000FF";
        player2Title[0].style.color = "#39FF14"

      } else if (this.turns % 2 === 0) {
        var player1Title = document.getElementsByClassName("player1-title");
        var player2Title = document.getElementsByClassName("player2-title");
        player2Title[0].style.color = "#FF0000FF";
        player1Title[0].style.color = "#39FF14"

      }
    },


    generateShipArray: function () {
      for (var i = 0; i < shipQuantityValueS; i++) {
        this.ships.push({locations: [0, 0, 0], hits: ["", "", ""]},);
      }
      this.generateShipScore();
      console.log("The current ship score:", this.shipScore);
    },

// original hard-coded values for ship locations
    /*
      ships: [
        { locations: ["06", "16", "26"], hits: ["", "", ""] },
        { locations: ["24", "34", "44"], hits: ["", "", ""] },
        { locations: ["10", "11", "12"], hits: ["", "", ""] }
      ],
    */

    generateShipScore: function () {
      if (parseInt(this.shipLength) === 1) {
        this.shipScore = 30;
      } else if (parseInt(this.shipLength) === 2) {
        this.shipScore = 20;
      } else {
        this.shipScore = 10;
      }
    },


    fire: function (guess) {
      for (var i = 0; i < this.numShips; i++) {
        var ship = this.ships[i];
        var index = ship.locations.indexOf(guess);

        // here's an improvement! Check to see if the ship
        // has already been hit, message the user, and return true.
        if (ship.hits[index] === "hit") {
          view.displayMessage("Oops, you already hit that location!");
          return true;
        } else if (index >= 0) {
          ship.hits[index] = "hit";
          if (parseInt(this.turns) % 2 === 1) {
            this.playerOneScore += this.shipScore;
          } else {
            this.playerTwoScore += this.shipScore;
          }
          view.displayHit(guess);
          view.displayMessage("HIT!");

          if (this.isSunk(ship)) {
            view.displayMessage("You sank my battleship!");
            this.shipsSunk++;
          }
          return true;
        }
      }
      view.displayMiss(guess);
      view.displayMessage("You missed.");
      return false;
    },

    isSunk: function (ship) {
      for (var i = 0; i < this.shipLength; i++) {
        if (ship.hits[i] !== "hit") {
          return false;
        }
      }
      return true;
    }

    ,

    generateShipLocations: function () {
      var locations;
      for (var i = 0; i < this.numShips; i++) {
        do {
          locations = this.generateShip();
        } while (this.collision(locations));
        this.ships[i].locations = locations;
      }
      console.log("Ships array: ");
      console.log(this.ships);
    }

    ,

    generateShip: function () {
      var direction = Math.floor(Math.random() * 2);
      var row, col;

      if (direction === 1) { // horizontal
        row = Math.floor(Math.random() * this.boardSize);
        col = Math.floor(Math.random() * (this.boardSize - this.shipLength + 1));
      } else { // vertical
        row = Math.floor(Math.random() * (this.boardSize - this.shipLength + 1));
        col = Math.floor(Math.random() * this.boardSize);
      }

      var newShipLocations = [];
      for (var i = 0; i < this.shipLength; i++) {
        if (direction === 1) {
          newShipLocations.push(row + "" + (col + i));
        } else {
          newShipLocations.push((row + i) + "" + col);
        }
      }
      return newShipLocations;
    }

    ,

    collision: function (locations) {
      for (var i = 0; i < this.numShips; i++) {
        var ship = this.ships[i];
        for (var j = 0; j < locations.length; j++) {
          if (ship.locations.indexOf(locations[j]) >= 0) {
            return true;
          }
        }
      }
      return false;
    }

  }
;


var view = {
  displayMessage: function (msg) {
    var messageArea = document.getElementById("messageArea");
    messageArea.innerHTML = msg;
  },

  displayHit: function (location) {
    var cell = document.getElementById(location);
    cell.setAttribute("class", "hit");
  },

  displayMiss: function (location) {
    var cell = document.getElementById(location);
    cell.setAttribute("class", "miss");
  },

  // displayWinSet: function(player) {
  //   var messageArea = document.getElementById("messageArea");
  //   messageArea.innerHTML = player + "won this set.";
  // },
  //
  // displayWinGame: function(player) {
  //   var messageArea = document.getElementById("messageArea");
  //   messageArea.innerHTML = player + "won this game.";
  // }

};

var controller = {
  guesses: 0,

  processGuess: function (guess) {
    var location = parseGuess(guess);
    if (location) {
      this.guesses++;
      var hit = model.fire(location);
      var playerOneWins = 0;
      var playerTwoWins = 0;
      var totalScoreSet = model.shipScore * model.numShips;
      model.turns++;
      model.changePlayerColor();
      var player1Score = document.getElementsByClassName("player1-score");
      player1Score[0].innerHTML = model.playerOneScore;
      var player2Score = document.getElementsByClassName("player2-score");
      player2Score[0].innerHTML = model.playerTwoScore;
      // console.log(model.playerOneScore, model.playerTwoScore);
      // console.log(model.turns);
      if (model.playerOneScore > (totalScoreSet) / 2) {
        view.displayMessage("Player one wins this set:", model.currentSet);
        playerOneWins++;
        model.currentSet++;
        var set = document.getElementsByClassName("set");
        set[0].innerHTML = model.currentSet;
        var setNow = model.currentSet;
        localStorage.setItem("setNow", setNow);
        window.location.reload();
        var getSetNow = localStorage.getItem("setNow");

        model.currentSet = getSetNow;
        console.log(model.currentSet);
        set[0].innerHTML = model.currentSet;

        // init();
      } else if (model.playerTwoScore > (totalScoreSet) / 2) {
        view.displayMessage("Player two wins this set:", model.currentSet);
        model.currentSet++;
        var set = document.getElementsByClassName("set");
        set[0].innerHTML = model.currentSet;
        playerTwoWins++;
        var setNow = model.currentSet;
        localStorage.setItem("setNow", setNow);
        // init();
        window.location.reload();
        var getSetNow = localStorage.getItem("setNow");
        model.currentSet = getSetNow;
        console.log(model.currentSet);
        set[0].innerHTML = model.currentSet;
      }

      if (model.currentSet === parseInt(model.setQuantity)) {
        if (playerOneWins > (model.setQuantity) / 2) {
          view.displayMessage("Player one wins the game.");
          model.currentSet = 0;
          localStorage.setItem("setNow", model.currentSet);

        } else if (playerTwoWins > (model.setQuantity) / 2) {
        }
        view.displayMessage("Player two wins the game.");
        model.currentSet = 0;
        localStorage.setItem("setNow", model.currentSet);
      }
      // if (hit && model.shipsSunk === model.numShips) {
      //   view.displayMessage("You sank all my battleships, in " + this.guesses + " guesses");
    }
  }
};


// helper function to parse a guess from the user

function parseGuess(guess) {
  var alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"];

  if (guess === null) {
    if (parseInt(model.boardSize) >= 10 && ((guess !== 3))) {
      alert("Oops, please enter a letter and a number on the board.");
    }
    // alert("Oops, please enter a letter and a number on the board.");
  } else {
    var firstChar = guess.charAt(0);
    var row = alphabet.indexOf(firstChar);
    // if (parseInt(model.boardSize) >= 10) {
    var column = guess.substring(1, 3);
    // var column = col;
    // console.log(column);
  }
  // var column = guess.charAt(1);

  // var column = col*1;

  if (isNaN(row) || isNaN(column)) {
    alert("Oops, that isn't on the board.");
  } else if (row < 0 || row > parseInt(model.boardSize) ||
    column < 0 || column > parseInt(model.boardSize)) {
    // console.log(row, column);
    // console.log(typeof model.boardSize);
    alert("Oops, that's off the board!");
  } else {
    // console.log(row + (column - 1));
    // console.log(typeof row, typeof column);
    return row + column;
  }
  return null;

}

// }


// event handlers

function handleFireButton() {
  var guessInput = document.getElementById("guessInput");
  var guess = guessInput.value.toUpperCase();

  controller.processGuess(guess);

  guessInput.value = "";
}

function handleKeyPress(e) {
  var fireButton = document.getElementById("fireButton");

  // in IE9 and earlier, the event object doesn't get passed
  // to the event handler correctly, so we use window.event instead.
  e = e || window.event;

  if (e.keyCode === 13) {
    fireButton.click();
    return false;
  }
}

var table = '<table id="board-table">';


function generateTable(value) {
  // var tableContent = document.createElement('table');
  // for (var i = 0; i < value.length; ++i) {
  //   // var record = list[i];
  //   var cell = document.createElement('td');
  //   var row = document.createElement('tr');
  //   // var textnode = document.createTextNode(record.Title);
  //   cell.appendChild(value);
  //   row.appendChild(cell);
  //   tableContent.appendChild(row);
  // }
  // tableContent.id = "orders";
  // document.getElementById("here").appendChild(tableContent);  // the table is added to the HTML div element
  // var rows = document.getElementById("orders").rows;
  // for (var i = 0; i < rows.length; ++i) {
  //   for (var j = 0; j < rows.length; ++j) {
  //     rows[i].id =(i) + (j);  // this is how you assign IDs
  //     console.log(rows[i]);
  //   }
  // }
  //OLD VERSION
  // var rows = document.getElementById("board-table").rows;

  for (var rowIndex = 0; rowIndex <= value; rowIndex++) {
    var row = "<tr><td>#" + rowIndex + "</td>";

    for (var colIndex = 0; colIndex <= value - 1; colIndex++) {
      row += "<td >" + colIndex + "</td>";

      // tr[rowIndex][colIndex.id = (rowIndex)+(colIndex)
    }
    // console.log(t[rowIndex][colIndex]);
    // tr.id = (rowIndex) + (colIndex);
    // d = t.getElementsByTagName("tr");
    // r = d.getElementsByTagName("td")[colIndex];
    // d.id = `${rowIndex}, ${colIndex}`;
    // }
    table += row + "</tr>";
    // console.log(table);

  }
  document.getElementById("game_board").innerHTML = table + "</table>";
  var t = document.getElementsByTagName("table")[0].rows; // This have to be the ID of your table, not the tag
  // var t = document.getElementsByTagName("table")[1].rows; // This have to be the ID of your table, not the tag
  // var last = t[0];
  // var cell = last.cells[0];
  // cell.id = "00"
  // console.log(last.cells[0], last.cells[2]);
  // console.log(last.cells[0], last.cells[1]);

// var tr = document.getElementsByTagName("tr");
//   console.log(t);
  // console.log(t.rows);
  for (var i = 0; i < t.length; i++) {
    var rowS = t[i];
    for (var j = 0; j < t.length; j++) {
      // tr[rowIndex][colIndex.id = (rowIndex)+(colIndex);
      // console.log(rowIndex, colIndex);
      // var cell = rowS;
      var cellS = rowS.cells[j];
      cellS.id = ("" + i + j);
      // console.log(cellS.id);
    }
  }
  // for (var i=0; i<rows.length; ++i) {
  //   rows[i].id =
  // }
  // table.id = "board-table";
}

// generateTableID(sizeBoardValueS);
// console.
// console.log(tr.id);

// function generateTableID(value) {
//     for (var rowIndex = 0; rowIndex <= value; rowIndex++) {
//         for (var colIndex = 0; colIndex < value; colIndex++) {
//           var d = t.getElementsByTagName("tr");
//           console.log(d);
//         // r = d.getElementsByTagName("td")[colIndex];
//         }
//     }
// }

function generateTableIndexes(value) {
  var alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"];

  for (i = 0; i < value; i++) {
    // console.log(i);
    for (j = parseInt(value); j <= value; j++) {
      ID = ("" + i + j);
      console.log(ID);

      // var cellID =
      // if (document.getElementById(ID)) {
      //   console.log("CELLID NOT NULL");
      // } else {
      //   console.log("NOT FOUND");
      // }
      // console.log(cellID.);
      document.getElementById(ID).innerHTML = "<h2>" +alphabet[i] + "</h2>";
      // var cellID = document.getElementById("" + i + j);

      // tr[rowIndex][colIndex.id = (rowIndex)+(colIndex)
    }
  }
  for (i = parseInt(value); i >= value; i--) {
    // console.log(i);
    for (j = 0; j < value; j++) {
      ID = ("" + i + j);

      console.log(ID);
      // if (document.getElementById(ID)) {
      //   console.log("CELLID NOT NULL");
      // } else {
      //   console.log("NOT FOUND");
      // }

      var cellID = document.getElementById(ID);
      document.getElementById(ID).innerHTML = "<h2>" + j + "</h2>";


      // var cellID = document.getElementById("" + i + j);

      // tr[rowIndex][colIndex.id = (rowIndex)+(colIndex)
    }
  }
}
