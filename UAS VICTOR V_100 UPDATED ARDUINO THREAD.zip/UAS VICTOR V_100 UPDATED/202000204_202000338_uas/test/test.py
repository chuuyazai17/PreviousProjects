from ImmerVerloren.service import ImmerVerlorenService
from kink import inject, di


def test_mendaftar_user_yang_sudah_terdaftar():
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"
    service = ImmerVerlorenService()
    service.initialize_repository()

    assert len(service.find_id_user(10001)) == 0

    one = service.create_account_staff("victor", "victor@gmail.com", "12345678")
    assert len(service.find_id_user(10001)) == 1
    assert one == "success"

    two = service.create_account_staff("victor", "victor@gmail.com", "12345678")
    assert two == "error_code_email_registered"


def test_menghapus_user_yang_sudah_terdaftar():
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"
    service = ImmerVerlorenService()
    service.initialize_repository()

    assert len(service.find_id_user(10001)) == 0  # no user

    one = service.create_account_staff("victor", "victor@gmail.com", "12345678")  # create user
    assert len(service.find_id_user(10001)) == 1  # user created
    assert one == "success"  # success register

    delete_ = service.delete_account(10001)  # delete
    assert len(service.find_id_user(10001)) == 0  # should be deleted
    assert delete_ == "success"


def test_menghapus_user_yang_tidak_terdaftar():
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"
    service = ImmerVerlorenService()
    service.initialize_repository()

    assert len(service.find_id_user(10001)) == 0  # no user

    delete_ = service.delete_account(10001)  # try to delete
    assert len(service.find_id_user(10001)) == 0  # should still no effect
    assert delete_ == "invalid"


# login page success
def test_pengambilan_barang_dengan_valid_id_dan_password():
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"
    service = ImmerVerlorenService()
    service.initialize_repository()

    assert len(service.find_id_user(10001)) == 0  # no user

    one = service.create_account_staff("victor", "victor@gmail.com", "12345678")
    assert len(service.find_id_user(10001)) == 1
    assert one == "success"

    login_status = service.login_user("10001", "12345678")
    assert login_status == "success"


# login page failed
def test_pengambilan_barang_dengan_id_dan_password_yang_salah():
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"
    service = ImmerVerlorenService()
    service.initialize_repository()

    assert len(service.find_id_user(10001)) == 0  # no user

    one = service.create_account_staff("victor", "victor@gmail.com", "12345678")
    assert len(service.find_id_user(10001)) == 1
    assert one == "success"

    login_status1 = service.login_user("10001", "1234567")    # wrong password
    assert login_status1 == "error"

    login_status2 = service.login_user("100011", "12345678")  # wrong id
    assert login_status2 == "error"

    login_status3 = service.login_user("100011", "1234678")   # wrong id & password
    assert login_status3 == "error"


def test_memasukkan_kotak_dengan_user_id_terdaftar():
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"
    service = ImmerVerlorenService()
    service.initialize_repository()

    assert len(service.find_id_user(10001)) == 0  # no user

    one = service.create_account_staff("victor", "victor@gmail.com", "12345678")
    assert len(service.find_id_user(10001)) == 1
    assert one == "success"

    status_courier = service.check_user_id_for_courier("10001")
    assert status_courier == "success"


def test_memasukkan_kotak_dengan_user_id_tidak_terdaftar():
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"
    service = ImmerVerlorenService()
    service.initialize_repository()

    assert len(service.find_id_user(10001)) == 0  # no user

    status_courier = service.check_user_id_for_courier("10001")
    assert status_courier == "error"

