import sqlite3
from sqlite3 import Error
from kink import inject, di


@inject
class Connectors:
    def __init__(self, db_file):
        self.file_database = db_file

    def create_connection(self):
        conn_1 = None
        try:
            conn_1 = sqlite3.connect(self.file_database)
            return conn_1
        except Error as e:
            print(e)
        return conn_1


@inject
class ImmerVerlorenRepository:
    def __init__(self, db_file, db_init: str = "False"):
        connection = Connectors(db_file).create_connection()
        self.conn = connection
        self.c = self.conn.cursor()
        self.db_init = db_init

        self.__operator_id = "admin"
        self.__operator_password = "admin"

    def __drop_table(self):
        def drop_table_users():
            table_users = """
                DROP TABLE users
            """
            self.c.execute(table_users)
            self.conn.commit()

        def drop_table_locker():
            table_locker = """
                DROP TABLE locker
            """
            self.c.execute(table_locker)
            self.conn.commit()

        def drop_table_deposit():
            table_deposit = """
                DROP TABLE deposit
            """
            self.c.execute(table_deposit)
            self.conn.commit()

        drop_table_users()
        drop_table_locker()
        drop_table_deposit()

    def __create_table(self):
        def create_table_users():
            table_users = """
                CREATE TABLE users(
                      id_user    INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_name    TEXT NOT NULL,
                   user_email    TEXT NOT NULL,
                     password    TEXT NOT NULL,
                          nim    TEXT DEFAULT NULL
                );
            """
            self.c.execute(table_users)
            self.conn.commit()

        def create_table_locker():
            table_locker = """
                CREATE TABLE locker(
                   no_locker    INTEGER PRIMARY KEY,
                        size    TEXT,
                      status    TEXT
                );
            """
            self.c.execute(table_locker)
            self.conn.commit()

        def create_table_deposit():
            table_deposit = """
                CREATE TABLE deposit(
                    id_deposit    INTEGER PRIMARY KEY AUTOINCREMENT,
                       id_user    INTEGER,
                     no_locker    INTEGER,
                    goods_type    TEXT NOT NULL,
                      finished    BIT (1),
                      time_put    DATETIME,
                     time_take    DATETIME,
                      FOREIGN KEY(id_user) REFERENCES users(id_user),
                      FOREIGN KEY(no_locker) REFERENCES locker(no_locker)
                );
            """
            self.c.execute(table_deposit)
            self.conn.commit()

        def insert_dummy_data_users():
            create_users = """
                INSERT INTO users(id_user, user_name, user_email, password, nim) 
                    values(10000, "dummy_user", "dummy_email@gmail.com", "dummy_password", -1);
                """
            self.c.execute(create_users)
            self.conn.commit()

        def insert_dummy_data_deposit():
            create_deposit = """
                INSERT INTO deposit(id_deposit, id_user, no_locker, goods_type, finished) 
                    values(1, 10000, 1, "dummy_package", 0);
            """
            self.c.execute(create_deposit)
            self.conn.commit()

        def insert_locker_data():
            create_locker_1 = """
                INSERT INTO locker(no_locker, size, status) 
                VALUES (1, "Big", "Available");
            """
            create_locker_2 = """
            INSERT INTO locker(no_locker, size, status) 
                VALUES (2, "Medium", "Available");
            """
            create_locker_3 = """
                INSERT INTO locker(no_locker, size, status) 
                VALUES (3, "Small", "Available");
            """

            create_locker_4 = """
                INSERT INTO locker(no_locker, size, status) 
                VALUES (4, "Small", "Available");
            """
            self.c.execute(create_locker_1)
            self.c.execute(create_locker_2)
            self.c.execute(create_locker_3)
            self.c.execute(create_locker_4)
            self.conn.commit()

        create_table_users()
        create_table_locker()
        create_table_deposit()

        insert_dummy_data_users()
        insert_dummy_data_deposit()
        insert_locker_data()

    def initialize(self):
        if self.db_init == "True":
            self.__drop_table()
            self.__create_table()
        elif self.db_init == "False":
            pass
        elif self.db_init == "Demo":
            pass  # under construction
        else:
            raise SystemError(f'db_init "{self.db_init}" is not recognize in our system!')

        return self.db_init


if __name__ == '__main__':
    database = r"schliessfach_testing_database"
    di["db_file"] = database
    di["db_init"] = "True"

    repo = ImmerVerlorenRepository()
    repo.initialize()
