import argparse
from kink import di

from ImmerVerloren.ui import ImmerVerlorenUI


if __name__ == '__main__':
    import_cmd = argparse.ArgumentParser()
    import_cmd.add_argument('-db_init')
    args = import_cmd.parse_args()
    # status = args.db_init
    status = "Demo"

    database1 = r"schliessfach_database"
    database2 = r"schliessfach_demo_database"

    if status == "True":
        print("true")
        di["db_file"] = database1
    elif status == "False":
        print("false")
    elif status == "Demo":
        print("demo")
        di["db_file"] = database2
    else:
        print("else")

    di["db_init"] = status

    apps = ImmerVerlorenUI()
    apps.run()
    # apps.show_list_user()
