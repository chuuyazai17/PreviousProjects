import re
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from kink import inject
import matplotlib.pyplot as plt
from dateutil import parser
from matplotlib import style

import tkinter as tk

from ImmerVerloren.service import ImmerVerlorenService, SignInSubject, FiveTimesWrongUserIDCourier, EmailToOperator, \
    SignUpSubject, UserIDNameEmail


@inject
class ImmerVerlorenUI:
    def __init__(self, service: ImmerVerlorenService):
        self.service = service
        self.unnecessary_attribute = False
        self.counter = 0

    def under_construction(self, username, password, before_window=None):
        username = username.get()
        password = password.get()

        if before_window is not None:
            before_window.destroy()

        print(username)
        print(password)

    def success_signup_message(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("250x220")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#79d173")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#79d173", height=220, width=250, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/z_signup_success_message/background.png")
        canvas.create_image(125.0, 116.5, image=background_img)

        got_it_butt = PhotoImage(file="../documents/z_signup_success_message/got_it_button.png")
        b0 = Button(image=got_it_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.user_page(x),
                    relief="flat")
        b0.place(x=82, y=186, width=85, height=20)

        window.mainloop()

    def success_login_message(self, id_user, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("250x220")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#79d173")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#7573d1", height=220, width=250, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/z_login_success_message/background.png")
        canvas.create_image(125.0, 116.5, image=background_img)

        got_it_butt = PhotoImage(file="../documents/z_login_success_message/got_it_button.png")
        b0 = Button(image=got_it_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=window: self.view_user_orders(id_user, x),
                    relief="flat")
        b0.place(x=82, y=186, width=85, height=20)

        window.mainloop()

    def error_message_user_login(self, id_user, password, before_window=None):
        id_user = id_user.get()
        password = password.get()

        login_status = self.service.login_user(id_user, password)
        if login_status == "blank":
            messagebox.showwarning("Warning!", f'Please fill out the blank!')
        elif login_status == "error":
            messagebox.showerror("Whoops!", f'Invalid id user or password!')
        else:
            if before_window is not None:
                before_window.destroy()

            self.success_login_message(id_user)

    def error_message_student_signup(self, name, nim, email, password, before_window=None):
        name = name.get()
        nim = nim.get()
        email = email.get()
        password = password.get()

        sign_up_status = self.service.create_account_student(name, email, password, nim)
        user_id = self.service.get_id_user_from_name(name)
        user_id_update = re.findall('\((.*?)\)', str(user_id))
        user_id_zero = user_id_update[0]
        user_id_fix = user_id_zero.split(',')
        deposit_observer = SignUpSubject()
        user_id_name_email = UserIDNameEmail(user_id_fix, name, email)

        if sign_up_status == "error_code_nim":
            messagebox.showerror("Whoops!", f'NIM already registered!')

        elif sign_up_status == "error_code_email_registered":
            messagebox.showerror("Whoops!", f'Email address already used!')

        elif sign_up_status == "error_code_email_invalid":
            messagebox.showerror("Whoops!", f'Invalid email address!')

        elif sign_up_status == "error_code_blank":
            messagebox.showwarning("Warning!", f'Please fill out the blank!')

        else:
            if before_window is not None:
                before_window.destroy()
            deposit_observer.notify_update(user_id_name_email)
            self.success_signup_message()

    def error_message_staff_signup(self, name, email, password, before_window=None):
        name = name.get()
        email = email.get()
        password = password.get()
        sign_up_status = self.service.create_account_staff(name, email, password)
        user_id = self.service.get_id_user_from_name(name)
        user_id_update = re.findall('\((.*?)\)', str(user_id))
        user_id_zero = user_id_update[0]
        user_id_fix = user_id_zero.split(',')
        deposit_observer = SignUpSubject()
        user_id_name_email = UserIDNameEmail(user_id_fix, name, email)

        if sign_up_status == "error_code_email_registered":
            messagebox.showerror("Whoops!", f'Email address already used!')

        elif sign_up_status == "error_code_email_invalid":
            messagebox.showerror("Whoops!", f'Invalid email address!')

        elif sign_up_status == "error_code_blank":
            messagebox.showwarning("Warning!", f'Please fill out the blank!')

        else:
            if before_window is not None:
                before_window.destroy()
            deposit_observer.notify_update(user_id_name_email)
            self.success_signup_message()

    def error_message_courier(self, id_user, before_window=None):
        deposit_observer = SignInSubject()

        id_user = id_user.get()
        email_to_operator = EmailToOperator()

        courier_status = self.service.check_user_id_for_courier(id_user)
        if courier_status == "blank":
            messagebox.showwarning("Warning!", f'Please fill out the blank!')
        elif courier_status == "error":
            self.counter += 1
            messagebox.showerror("Whoops!", f'Invalid id user!')
            if self.counter == 5:
                deposit_observer.notify_update(email_to_operator)
            print(self.counter)
        else:
            messagebox.showinfo("Success!", "Login success!")
            self.deposit_ui(id_user, before_window)

    def error_message_operator_login(self, username, password, before_window=None):
        username = username.get()
        password = password.get()

        status_login = self.service.check_operator_id_and_password(username, password)
        if status_login == "blank":
            messagebox.showwarning("Warning!", f'Please fill out the blank!')
        elif status_login == "invalid":
            messagebox.showerror("Whoops!", f'Invalid username or password!')
        else:
            messagebox.showinfo("Success!", "Login success!")
            self.operator_view(before_window)

    def error_message_delete_account(self, id_user):
        id_user = id_user.get()
        delete_status = self.service.delete_account(id_user)

        if len(id_user) == 0:
            messagebox.showwarning("Warning!", f'Please fill out the blank!')
        elif delete_status == "invalid":
            messagebox.showerror("Whoops!", f'Id user "{id_user}" does not exist!')
        else:
            messagebox.showinfo("Success!", f'Id user "{id_user}" has been removed!')

    def homepage(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0,
                        relief="ridge")
        canvas.place(x=0, y=0)

        background = PhotoImage(file="../documents/01_homepage_img/background.png")
        canvas.create_image(510.0, 300.0, image=background)

        user = PhotoImage(file="../documents/01_homepage_img/user.png")
        b1 = Button(image=user, borderwidth=0, highlightthickness=0, command=lambda x=window: self.user_page(x),
                    relief="flat")
        b1.place(x=397, y=281, width=225, height=61)

        courier = PhotoImage(file="../documents/01_homepage_img/courier.png")
        b2 = Button(image=courier, borderwidth=0, highlightthickness=0, command=lambda x=window: self.courier_page(x),
                    relief="flat")
        b2.place(x=397, y=366, width=225, height=61)

        operator = PhotoImage(file="../documents/01_homepage_img/operator.png")
        b3 = Button(image=operator, borderwidth=0, highlightthickness=0, command=lambda x=window: self.operator_page(x),
                    relief="flat")
        b3.place(x=397, y=451, width=225, height=61)

        def ask_to_quit():
            if messagebox.askyesno("Exit", 'Are you sure want to quit?'):
                window.destroy()

        exit_ = PhotoImage(file="../documents/01_homepage_img/exit.png")
        exit_butt = Button(image=exit_, borderwidth=0, highlightthickness=0, command=ask_to_quit, relief="flat")
        exit_butt.place(x=896, y=544, width=94, height=37)

        # Information
        if self.unnecessary_attribute is False:
            messagebox.showinfo("Information", f'db_init set to "{initialize}" !')
            self.unnecessary_attribute = True

        window.mainloop()

    def user_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/01a_user_page_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        student_login = PhotoImage(file="../documents/01a_user_page_img/00_student_login.png")
        b0 = Button(image=student_login, borderwidth=0, highlightthickness=0,
                    command=lambda x=window: self.login_page(x), relief="flat")
        b0.place(x=427, y=167, width=166, height=32)

        staff_login = PhotoImage(file="../documents/01a_user_page_img/01_staff_login.png")
        b1 = Button(image=staff_login, borderwidth=0, highlightthickness=0, command=lambda x=window: self.login_page(x),
                    relief="flat")
        b1.place(x=427, y=217, width=166, height=32)

        student_signup = PhotoImage(file="../documents/01a_user_page_img/02_student_signup.png")
        b2 = Button(image=student_signup, borderwidth=0, highlightthickness=0,
                    command=lambda x=window: self.signup_student_page(x), relief="flat")
        b2.place(x=427, y=346, width=166, height=32)

        staff_signup = PhotoImage(file="../documents/01a_user_page_img/03_staff_signup.png")
        b3 = Button(image=staff_signup, borderwidth=0, highlightthickness=0,
                    command=lambda x=window: self.signup_staff_page(x), relief="flat")
        b3.place(x=427, y=396, width=166, height=32)

        back_butt = PhotoImage(file="../documents/01a_user_page_img/back.png")
        b4 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.homepage(x),
                    relief="flat")
        b4.place(x=324, y=98, width=49, height=29)

        window.mainloop()

    def courier_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/02_courier_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        id_user_img = PhotoImage(file="../documents/02_courier_img/id_user_img_textbox.png")
        canvas.create_image(495.0, 308.5, image=id_user_img)
        id_user = Entry(bd=0, bg="#f5f5f5", highlightthickness=0)
        id_user.place(x=380, y=291, width=230, height=33)

        confirm_butt = PhotoImage(file="../documents/02_courier_img/confirm.png")
        b0 = Button(image=confirm_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=(id_user, window): self.error_message_courier(x[0], x[1]),
                    relief="flat")
        b0.place(x=610, y=291, width=35, height=35)

        back_butt = PhotoImage(file="../documents/02_courier_img/back.png")
        b1 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.homepage(x),
                    relief="flat")
        b1.place(x=364, y=150, width=41, height=25)

        window.mainloop()

    def operator_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/03_operator_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        username_img = PhotoImage(file="../documents/03_operator_img/username_img_textbox.png")
        canvas.create_image(512.0, 261.0, image=username_img)
        username = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        username.place(x=397, y=246, width=230, height=28)

        password_img = PhotoImage(file="../documents/03_operator_img/password_img_textbox.png")
        canvas.create_image(512.0, 329.0, image=password_img)
        password = Entry(bd=0, bg="#e0e0e0", highlightthickness=0, show="*")
        password.place(x=397, y=314, width=230, height=28)

        login_butt = PhotoImage(file="../documents/03_operator_img/login_button.png")
        b1 = Button(image=login_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=(username, password): self.error_message_operator_login(x[0], x[1], window),
                    relief="flat")
        b1.place(x=463, y=358, width=93, height=32)

        back_butt = PhotoImage(file="../documents/03_operator_img/back.png")
        b0 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.homepage(x),
                    relief="flat")
        b0.place(x=358, y=133, width=41, height=25)

        window.mainloop()

    def login_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/01aa_login_page_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        id_user_img = PhotoImage(file="../documents/01aa_login_page_img/id_user_img_textbox.png")
        canvas.create_image(512.0, 265.0, image=id_user_img)
        id_user = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        id_user.place(x=397, y=250, width=230, height=28)

        password_img = PhotoImage(file="../documents/01aa_login_page_img/password_img_textbox.png")
        canvas.create_image(512.0, 330.0, image=password_img)
        password = Entry(bd=0, bg="#e0e0e0", highlightthickness=0, show="*")
        password.place(x=397, y=315, width=230, height=28)

        login_butt = PhotoImage(file="../documents/01aa_login_page_img/login_button.png")
        b0 = Button(image=login_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=(id_user, password): self.error_message_user_login(x[0], x[1], window),
                    relief="flat")
        b0.place(x=463, y=378, width=93, height=32)

        back_butt = PhotoImage(file="../documents/01aa_login_page_img/back.png")
        b1 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.user_page(x),
                    relief="flat")
        b1.place(x=325, y=101, width=41, height=25)

        window.mainloop()

    def signup_student_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/01ab_signup_student_page_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        name_img = PhotoImage(file="../documents/01ab_signup_student_page_img/name_img_textbox.png")
        canvas.create_image(515.0, 216.0, image=name_img)
        name = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        name.place(x=400, y=201, width=230, height=28)

        nim_img = PhotoImage(file="../documents/01ab_signup_student_page_img/nim_img_textbox.png")
        canvas.create_image(515.0, 272.0, image=nim_img)
        nim = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        nim.place(x=400, y=257, width=230, height=28)

        email_img = PhotoImage(file="../documents/01ab_signup_student_page_img/email_img_textbox.png")
        canvas.create_image(515.0, 328.0, image=email_img)
        email = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        email.place(x=400, y=313, width=230, height=28)

        password_img = PhotoImage(file="../documents/01ab_signup_student_page_img/password_img_textbox.png")
        canvas.create_image(515.0, 386.0, image=password_img)
        password = Entry(bd=0, bg="#e0e0e0", highlightthickness=0, show="*")
        password.place(x=400, y=371, width=230, height=28)

        signup_butt = PhotoImage(file="../documents/01ab_signup_student_page_img/signup_button.png")
        b0 = Button(image=signup_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=(name, nim, email, password): self.error_message_student_signup(x[0], x[1], x[2],
                                                                                                     x[3], window),
                    relief="flat")
        b0.place(x=463, y=420, width=93, height=32)

        back_butt = PhotoImage(file="../documents/01ab_signup_student_page_img/back.png")
        b1 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.user_page(x),
                    relief="flat")
        b1.place(x=325, y=101, width=41, height=25)

        window.mainloop()

    def signup_staff_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        name_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/name_img_textbox.png")
        canvas.create_image(515.0, 246.0, image=name_img)
        name = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        name.place(x=400, y=231, width=230, height=28)

        email_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/email_img_textbox.png")
        canvas.create_image(515.0, 304.0, image=email_img)
        email = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        email.place(x=400, y=289, width=230, height=28)

        password_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/password_img_textbox.png")
        canvas.create_image(515.0, 362.0, image=password_img)
        password = Entry(bd=0, bg="#e0e0e0", highlightthickness=0, show="*")
        password.place(x=400, y=347, width=230, height=28)

        signup_butt = PhotoImage(file="../documents/01ac_signup_staff_page_img/signup_button.png")
        b0 = Button(image=signup_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=(name, email, password): self.error_message_staff_signup(x[0], x[1], x[2], window),
                    relief="flat")
        b0.place(x=463, y=396, width=93, height=32)

        back_butt = PhotoImage(file="../documents/01ac_signup_staff_page_img/back.png")
        b1 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.user_page(x),
                    relief="flat")
        b1.place(x=325, y=101, width=41, height=25)

        window.mainloop()

    def confirm_drop_package(self, id_user, locker_num, goods_type):
        goods_type = goods_type.get()

        # call service to check if locker available or not
        if messagebox.askokcancel("Confirm?", f"Drop package?\n\n"
                                              f"Locker number : {locker_num}\n"
                                              f"Package type    : {goods_type}"):
            if self.service.check_if_locker_empty_or_not(id_user, locker_num, goods_type) == "Available":
                self.service.open_servo(locker_num)
                if messagebox.askyesno("Close?", "Close door?"):
                    self.service.close_servo(locker_num)
                    messagebox.showinfo("Done!", "Package dropped!")

            else:
                messagebox.showerror("Whoops!", f"Locker {locker_num} is unavailable!")

    # for courier
    def deposit_ui(self, id_user, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        locker1 = 1
        locker2 = 2
        locker3 = 3
        locker4 = 4

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/02a_drop_package/background.png")
        canvas.create_image(680.0, 225.5, image=background_img)

        options = ["Books", "Clothes", "Stationary", "Food", "etc"]
        variable = StringVar(window)
        variable.set(options[0])

        type_list = OptionMenu(window, variable, *options)
        type_list.place(x=625, y=255, width=304, height=43)

        one_big = PhotoImage(file="../documents/02a_drop_package/1_big.png")
        b1 = Button(image=one_big, borderwidth=0, highlightthickness=0,
                    command=lambda x=locker1: self.confirm_drop_package(id_user, x, variable), relief="flat")
        b1.place(x=113, y=76, width=189, height=180)

        two_medium = PhotoImage(file="../documents/02a_drop_package/2_medium.png")
        b2 = Button(image=two_medium, borderwidth=0, highlightthickness=0,
                    command=lambda x=locker2: self.confirm_drop_package(id_user, x, variable), relief="flat")
        b2.place(x=348, y=76, width=189, height=180)

        three_small = PhotoImage(file="../documents/02a_drop_package/3_small.png")
        b3 = Button(image=three_small, borderwidth=0, highlightthickness=0,
                    command=lambda x=locker3: self.confirm_drop_package(id_user, x, variable), relief="flat")
        b3.place(x=113, y=323, width=189, height=180)

        four_small = PhotoImage(file="../documents/02a_drop_package/4_small.png")
        b4 = Button(image=four_small, borderwidth=0, highlightthickness=0,
                    command=lambda x=locker4: self.confirm_drop_package(id_user, x, variable), relief="flat")
        b4.place(x=348, y=323, width=189, height=180)

        back_butt = PhotoImage(file="../documents/02a_drop_package/back.png")
        b0 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.courier_page(x),
                    relief="flat")
        b0.place(x=36, y=32, width=61.5, height=37.5)

        # b5 = Button(text="CLOSE", borderwidth=0, highlightthickness=0, command=lambda: self.service.close_servo(locker), relief="flat")
        # b5.place(x=625, y=300, width=100, height=40)

        window.mainloop()

    # for users after login success
    def view_user_orders(self, user_id, before_window=None):
        if before_window is not None:
            before_window.destroy()

        root = tk.Tk()

        tree = ttk.Treeview(root, column=("c1", "c2", "c3"), show='headings')

        tree.column("#1", anchor=tk.CENTER)

        tree.heading("#1", text="NO LOKER")

        tree.column("#2", anchor=tk.CENTER)

        tree.heading("#2", text="GOODS TYPE")

        tree.pack()

        rows = self.service.view_user_orders(user_id)

        for row in rows:
            print(row)
            tree.insert("", tk.END, values=row)

        OPTIONS = self.service.view_users_only_lockers(user_id)

        variable = StringVar(root)

        w = OptionMenu(root, variable, *OPTIONS)
        w.pack()

        take_goods = []

        def ok_2():
            take_goods.append(
            variable.get()
            )
            print(take_goods)

        button = Button(root, text="CONFIRM", command=ok_2)
        button.pack()

        def take_it_now():
            for i in take_goods:
                i_update = re.findall('\((.*?)\)', i)
                i_zero = i_update[0]
                i_updated = i_zero.split(',')
                print(int(i_updated[0]))
                self.service.open_servo(int(i_updated[0]))
                self.service.remove_goods(int(i_updated[0]))
                if messagebox.askyesno("Close?", "Close door?"):
                    self.service.close_servo(int(i_updated[0]))
                    messagebox.showinfo("Done!", "Package dropped!")

        button2 = Button(root, text="TAKE", command=take_it_now)
        button2.pack()
        root.mainloop()

    def operator_view(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/03a_after_operator_login_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        img0 = PhotoImage(file="../documents/03a_after_operator_login_img/back.png")
        back = Button(image=img0, borderwidth=0, highlightthickness=0,
                      command=lambda x=window: self.operator_page(x), relief="flat")
        back.place(x=75, y=59, width=69, height=41)

        img2 = PhotoImage(file="../documents/03a_after_operator_login_img/show_graphic_img.png")
        graph_butt = Button(image=img2, borderwidth=0, highlightthickness=0,
                            command=lambda x=window: self.which_graph(x), relief="flat")
        graph_butt.place(x=428, y=265, width=164, height=123)

        img3 = PhotoImage(file="../documents/03a_after_operator_login_img/create_account_staff.png")
        staff_butt = Button(image=img3, borderwidth=0, highlightthickness=0,
                            command=lambda x=window: self.operator_signup_staff_page(x), relief="flat")
        staff_butt.place(x=108, y=349, width=200, height=92)

        img4 = PhotoImage(file="../documents/03a_after_operator_login_img/create_account_student.png")
        student_butt = Button(image=img4, borderwidth=0, highlightthickness=0,
                              command=lambda x=window: self.operator_signup_student_page(x), relief="flat")
        student_butt.place(x=108, y=219, width=200, height=92)

        all_users = Button(text="All users", command=lambda x=window: self.show_list_user(x))
        all_users.place(x=108, y=481, width=200, height=28)

        entry0_img = PhotoImage(file="../documents/03a_after_operator_login_img/id_user_textbox_img.png")
        canvas.create_image(830.0, 296.0, image=entry0_img)
        id_user = Entry(bd=0, bg="#ffffff", highlightthickness=0)
        id_user.place(x=730, y=281, width=200, height=28)

        img1 = PhotoImage(file="../documents/03a_after_operator_login_img/delete_account_img.png")
        delete_butt = Button(image=img1, borderwidth=0, highlightthickness=0,
                             command=lambda x=id_user: self.error_message_delete_account(x), relief="flat")
        delete_butt.place(x=738, y=335, width=165, height=32)

        window.mainloop()

    def operator_signup_student_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")  
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/01ab_signup_student_page_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        name_img = PhotoImage(file="../documents/01ab_signup_student_page_img/name_img_textbox.png")
        canvas.create_image(515.0, 216.0, image=name_img)
        name = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        name.place(x=400, y=201, width=230, height=28)

        nim_img = PhotoImage(file="../documents/01ab_signup_student_page_img/nim_img_textbox.png")
        canvas.create_image(515.0, 272.0, image=nim_img)
        nim = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        nim.place(x=400, y=257, width=230, height=28)

        email_img = PhotoImage(file="../documents/01ab_signup_student_page_img/email_img_textbox.png")
        canvas.create_image(515.0, 328.0, image=email_img)
        email = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        email.place(x=400, y=313, width=230, height=28)

        password_img = PhotoImage(file="../documents/01ab_signup_student_page_img/password_img_textbox.png")
        canvas.create_image(515.0, 386.0, image=password_img)
        password = Entry(bd=0, bg="#e0e0e0", highlightthickness=0, show="*")
        password.place(x=400, y=371, width=230, height=28)

        signup_butt = PhotoImage(file="../documents/01ab_signup_student_page_img/signup_button.png")
        b0 = Button(image=signup_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=(name, nim, email, password): self.error_message_student_signup(x[0], x[1], x[2],
                                                                                                     x[3], window),
                    relief="flat")
        b0.place(x=463, y=420, width=93, height=32)

        back_butt = PhotoImage(file="../documents/01ab_signup_student_page_img/back.png")
        b1 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.operator_view(x),
                    relief="flat")
        b1.place(x=325, y=101, width=41, height=25)

        window.mainloop()

    def operator_signup_staff_page(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("1020x600")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        canvas = Canvas(window, bg="#ffffff", height=600, width=1020, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/background.png")
        canvas.create_image(510.0, 300.0, image=background_img)

        name_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/name_img_textbox.png")
        canvas.create_image(515.0, 246.0, image=name_img)
        name = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        name.place(x=400, y=231, width=230, height=28)

        email_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/email_img_textbox.png")
        canvas.create_image(515.0, 304.0, image=email_img)
        email = Entry(bd=0, bg="#e0e0e0", highlightthickness=0)
        email.place(x=400, y=289, width=230, height=28)

        password_img = PhotoImage(file="../documents/01ac_signup_staff_page_img/password_img_textbox.png")
        canvas.create_image(515.0, 362.0, image=password_img)
        password = Entry(bd=0, bg="#e0e0e0", highlightthickness=0, show="*")
        password.place(x=400, y=347, width=230, height=28)

        signup_butt = PhotoImage(file="../documents/01ac_signup_staff_page_img/signup_button.png")
        b0 = Button(image=signup_butt, borderwidth=0, highlightthickness=0,
                    command=lambda x=(name, email, password): self.error_message_staff_signup(x[0], x[1], x[2], window),
                    relief="flat")
        b0.place(x=463, y=396, width=93, height=32)

        back_butt = PhotoImage(file="../documents/01ac_signup_staff_page_img/back.png")
        b1 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=window: self.operator_view(x),
                    relief="flat")
        b1.place(x=325, y=101, width=41, height=25)

        window.mainloop()

    def which_graph(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        window = Tk()
        window.title("SchliessFach App")
        window.geometry("500x300")
        window.wm_iconbitmap("../documents/01_homepage_img/schliessfach_ico.ico")
        window.configure(bg="#ffffff")
        window.resizable(False, False)

        button1 = Button(text="Graph goods type per time",
                         command=lambda x=window: self.show_graph_per_time_per_goods_type(x), relief="flat")
        button1.place(x=314, y=140)

        button2 = Button(text="Graph size per time",
                         command=lambda x=window: self.show_graph_per_time_per_size(x), relief="flat")
        button2.place(x=55, y=140)

    def show_graph_per_time_per_goods_type(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        graph_data = self.service.duration_per_time_per_goods_type_query()

        goods_type = []
        duration = []

        for rows in graph_data:
            duration.append(rows[1])
            goods_type.append(rows[0])
            
        plt.plot(goods_type, duration, '-')
        plt.show()

        style.use('fivethirtyeight')

    def show_graph_per_time_per_size(self, before_window=None):
        if before_window is not None:
            before_window.destroy()

        graph_data = self.service.duration_per_item_size()

        size = []
        duration = []

        for rows in graph_data:
            duration.append(rows[1])
            size.append(rows[0])

        plt.plot(size, duration, '-')
        plt.show()

        style.use('fivethirtyeight')

    def show_list_user(self, before_window = None):
        if before_window is not None:
            before_window.destroy()

        root = tk.Tk()

        tree = ttk.Treeview(root, column=("c1", "c2", "c3", "c4", "c5"), show='headings')

        tree.column("#1", anchor=tk.CENTER)

        tree.heading("#1", text="ID USER")

        tree.column("#2", anchor=tk.CENTER)

        tree.heading("#2", text="NAME")

        tree.column("#3", anchor=tk.CENTER)

        tree.heading("#3", text="EMAIL")

        tree.column("#4", anchor=tk.CENTER)

        tree.heading("#4", text="PASSWORD")

        tree.column("#5", anchor=tk.CENTER)

        tree.heading("#5", text="NIM")

        rows = self.service.get_all_user()

        i = 0
        for x in rows:
            tree.insert("", index=i, values=[x[0], x[1], x[2], x[3], x[4]])
            i += 1

        back_butt = PhotoImage(file="../documents/01ab_signup_student_page_img/back.png")
        b1 = Button(image=back_butt, borderwidth=0, highlightthickness=0, command=lambda x=root: self.operator_view(x),
                    relief="flat")
        b1.place(x=325, y=101, width=41, height=25)

        tree.pack()
        root.mainloop()

    def countdown_five_sec(self, before_window=None):
        print("clicked")
        label = tk.Label(self, text='', width=10)
        label.pack()
        self.remaining = 0
        self.countdown(5)

        def countdown(remaining=None):
            if remaining is not None:
                self.remaining = remaining
                # pass

            if remaining <= 0:
                label.configure(text="time's up!")
            else:
                label.configure(text="%d" % remaining)
                remaining = remaining - 1
                self.after(1000, self.countdown)

        label.mainloop()

    def run(self):
        global initialize
        initialize = self.service.initialize_repository()

        self.homepage()
