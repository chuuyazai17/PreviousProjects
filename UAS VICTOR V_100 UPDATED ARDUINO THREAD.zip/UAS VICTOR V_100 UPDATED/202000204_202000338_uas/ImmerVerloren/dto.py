class AccountDTO:
    def __init__(self, id_num, acc_name, acc_email, password, nim, time_diff):
        self.id_num = id_num
        self.acc_name = acc_name
        self.acc_email = acc_email
        self.password = password
        self.nim = nim
        self.time_diff = time_diff


class DepositDTO:
    def __init__(self, id_deposit, id_num, locker_num, goods_type, finished, time_put, time_take):
        self.id_deposit = id_deposit
        self.id_num = id_num
        self.locker_num = locker_num
        self.goods_type = goods_type
        self.finished = finished
        self.time_put = time_put
        self.time_take = time_take


class LockerDTO:
    def __init__(self, locker_num, capacity):
        self.locker_num = locker_num
        self.capacity = capacity
