import re  # Library for checking validity email address
import smtplib
import ssl

from abc import abstractmethod
from typing import List
from kink import inject, di

from ImmerVerloren.repository import ImmerVerlorenRepository
from ImmerVerloren.servo import *


@inject
class ImmerVerlorenService:
    def __init__(self, repository: ImmerVerlorenRepository):
        self.repository = repository
        self.counter = 0

    def initialize_repository(self):
        return self.repository.initialize()

    def operator_id(self):
        return self.repository.get_operator_id()

    def operator_password(self):
        return self.repository.get_operator_password()

    def check_operator_id_and_password(self, username_operator, password):
        if len(username_operator) == 0:
            return "blank"
        elif len(password) == 0:
            return "blank"
        elif username_operator == self.operator_id():
            if password == self.operator_password():
                return "success"
            else:
                return "invalid"
        else:
            return "invalid"

    def check_nim_validation(self, nim):
        stat = False
        if len(self.find_nim(nim)) != 0:
            stat = True

        return stat

    def check_email_validation(self, acc_email):
        regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'
        stat = False

        if (re.search(regex, acc_email)):
            stat = True

        return stat

    def check_email_registered(self, acc_email):
        stat = False
        if len(self.find_email(acc_email)) != 0:
            stat = True

        return stat

    def check_user_id_for_courier(self, user_id):
        if len(user_id) == 0:
            return "blank"
        elif len(self.find_id_user(user_id)) == 0:
            return "error"
        else:
            return "success"

    def add_goods(self, id_user, no_locker, goods_type):
        self.repository.add_goods(id_user, no_locker, goods_type)
        self.repository.change_locker_status_full(no_locker)

    def remove_goods(self, locker_num):
        self.repository.remove_goods(locker_num)
        self.repository.change_locker_status_available(locker_num)

    def login_user(self, id_user, password):
        if len(id_user) == 0:
            return "blank"
        elif len(password) == 0:
            return "blank"
        # id_user don't exist (let's say invalid)
        elif len(self.find_id_user(int(id_user))) == 0:
            return "error"
        # id_user exist (next we check password)
        else:
            # check validity password
            if len(self.find_id_user_and_password(int(id_user), password)) == 0:
                return "error"
            else:
                return "success"

    def create_account_student(self, acc_name, acc_email, passcode, nim):
        # Check blank input field (error_code_blank)
        if len(acc_name) == 0:
            return "error_code_blank"
        elif len(acc_email) == 0:
            return "error_code_blank"
        elif len(passcode) == 0:
            return "error_code_blank"
        elif len(nim) == 0:
            return "error_code_blank"

        # Check availability nim (error_code_nim)
        elif self.check_nim_validation(nim) is True:
            return "error_code_nim"

        # Check email if it already (error_code_email_registered)
        elif self.check_email_registered(acc_email) is True:
            return "error_code_email_registered"

        # Check validity email (error_code_email_invalid)
        elif self.check_email_validation(acc_email) is False:
            return "error_code_email_invalid"

        # If 3 conditions are fulfilled, then create account
        else:
            self.repository.create_account(acc_name, acc_email, passcode, nim)
            return "success"

    def create_account_staff(self, acc_name, acc_email, passcode):
        # Check blank input field (error_code_blank)
        if len(acc_name) == 0:
            return "error_code_blank"
        elif len(acc_email) == 0:
            return "error_code_blank"
        elif len(passcode) == 0:
            return "error_code_blank"

        # Check email if it already (error_code_email_registered)
        elif self.check_email_registered(acc_email) is True:
            return "error_code_email_registered"

        # Check validity email (error_code_email_invalid)
        elif self.check_email_validation(acc_email) is False:
            return "error_code_email_invalid"

        # If 2 conditions are fulfilled, then create account
        else:
            self.repository.create_account(acc_name, acc_email, passcode, None)
            return "success"

    def delete_account(self, id_num):
        if len(self.find_id_user(id_num)) == 0:
            return "invalid"
        else:
            self.repository.delete_account(id_num)
            return "success"

    def get_all_lockers(self):
        return self.repository.get_all_lockers()

    def get_all_accounts(self):
        return self.repository.get_all_accounts()

    def get_all_deposit(self):
        return self.repository.get_all_deposit()

    def find_id_user(self, id_num):
        return self.repository.find_id_user(id_num)

    def find_id_user_and_password(self, id_num, password):
        return self.repository.find_id_user_and_password(id_num, password)

    def find_email(self, email):
        return self.repository.find_email(email)

    def find_nim(self, nim):
        return self.repository.find_nim(nim)

    def view_user_orders(self, user_id):
        return self.repository.view_user_orders(user_id)

    def view_users_only_lockers(self, user_id):
        return self.repository.view_users_orders_only_lockers(user_id)

    def get_id_user_from_name(self, name):
        return self.repository.get_id_user_from_name(name)

    def get_filled_lockers(self):
        return self.repository.get_filled_locker()

    def check_if_locker_empty_or_not(self, id_user, locker_num, goods_type):
        filled_locker = self.repository.get_unfinished_lockers(locker_num)
        if len(filled_locker) == 0:  # available
            self.add_goods(id_user, locker_num, goods_type)
            return f"Available"
        else:
            return f"Unavailable"

    def duration_per_time_per_goods_type_query(self):
        return self.repository.duration_per_item_type_query()

    def duration_per_item_size(self):
        return self.repository.duration_per_item_size()

    def define_locker_pin(self, locker):
        if locker == 1:
            return 5
        elif locker == 2:
            return 3
        elif locker == 3:
            return 9
        elif locker == 4:
            return 6
        else:
            pass

    def open_servo(self, locker):
        pin = self.define_locker_pin(locker)
        if pin == 3:
            OpenServoThree()
        elif pin == 9:
            OpenServoNine()
        elif pin == 5:
            OpenServoFive()
        elif pin == 6:
            OpenServoSix()
        else:
            pass

    def close_servo(self, locker):
        pin = self.define_locker_pin(locker)
        if pin == 3:
            CloseServoThree()
        elif pin == 9:
            CloseServoNine()
        elif pin == 5:
            CloseServoFive()
        elif pin == 6:
            CloseServoSix()
        else:
            pass

    def get_all_user(self):
        return self.repository.get_all_user()


class Message:  # Send email algorithm
    pass


class Observer:
    @abstractmethod
    def notified(self, message: Message):
        pass


class Subject:
    @abstractmethod
    def notify_update(self, message: Message):
        pass


class UserIDNameEmail(Message):
    def __init__(self, user_id, name, email):
        self.user_id = user_id
        self.name = name
        self.email = email


class EmailToOperator(Message):
    def __init__(self):
        self.operator_email = "jessicawakilketuabem2022@gmail.com"
        self.sender_email = "victorketuabem2022@gmail.com"
        self.sender_password = "ayoyukbisayuk"
        self.smtp_server = "smtp.gmail.com"


class UserIDNameEmailObserver(Observer):
    def notified(self, message: Message):
        pass


class OperatorObserver(Observer):
    def notified(self, message: Message):
        pass


class LockerFullObserver(Observer):
    def notified(self, message: Message):
        pass


@inject
class SignInSubject(Subject):
    def __init__(self, observer: List[OperatorObserver]):
        self.observers = observer

    def notify_update(self, message: Message):
        for i in self.observers:
            i.notified(message)


@inject
class SignUpSubject(Subject):
    def __init__(self, observer: List[UserIDNameEmailObserver]):
        self.observers = observer

    def notify_update(self, message: Message):
        for i in self.observers:
            i.notified(message)


@inject
class LockerSubject(Subject):
    def __init__(self, observer: List[LockerFullObserver]):
        self.observers = observer

    def notify_update(self, message: Message):
        for i in self.observers:
            i.notified(message)


@inject(alias=OperatorObserver)
class FiveTimesWrongUserIDCourier(Observer):
    def notified(self, message: EmailToOperator):
        port = 465
        smtp_server = message.smtp_server
        sender_email = message.sender_email
        receiver_email = message.operator_email
        password = message.sender_password
        subject = "[IMPORTANT] WARNING! "
        message_input = "A courier has failed to log in 5 times."
        message = f"""\
        Subject: {subject}

        {message_input}"""

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)


@inject(alias=UserIDNameEmailObserver)
class SuccessSignUpObserver(Observer):
    def notified(self, message: UserIDNameEmail):
        smtp_server = "smtp.gmail.com"
        sender_email = "victorketuabem2022@gmail.com"
        receiver_email = message.email
        password = "ayoyukbisayuk"
        subject = "Sign Up Successful! "
        message_input = f"Congratulations {message.name}, your sign up is successful. Here is your id: {message.user_id}."
        message = f"""\
                Subject: {subject}

                {message_input}"""

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, 465, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)


@inject(alias=LockerFullObserver)
class IfLockerFullThenEmailOperator(Observer):
    def notified(self, message: EmailToOperator):
        port = 465
        smtp_server = message.smtp_server
        sender_email = message.sender_email
        receiver_email = message.operator_email
        password = message.sender_password
        subject = "[IMPORTANT] WARNING! "
        message_input = "Locker is almost full."
        message = f"""\
                Subject: {subject}

                {message_input}"""

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)


if __name__ == "__main__":
    database = r"schliessfach_demo_database"
    di["db_file"] = database
    di["db_init"] = "False"
    service = ImmerVerlorenService()
    # service.open_servo(3)
    # service.close_servo(3)
    print(service.get_all_user())
