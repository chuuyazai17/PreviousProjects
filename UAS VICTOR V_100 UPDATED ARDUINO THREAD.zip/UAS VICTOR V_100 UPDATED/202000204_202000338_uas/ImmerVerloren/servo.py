from pyfirmata import Arduino, SERVO
import threading
from time import sleep


class Servo:
    def __init__(self, pin):
        self.port = 'COM10'
        self.board = Arduino(self.port)
        self.pin = pin
        self.board.digital[self.pin].mode = SERVO

    def rotateServo(self, pin, angle):
        self.board.digital[pin].write(angle)
        sleep(0.015)

    def open_servo_three(self):
        for i in range(90, 180):
            self.board.digital[3].write(i)
            sleep(0.015)

    def close_servo_three(self):
        for i in range(180, 90, -1):
            self.board.digital[3].write(i)
            sleep(0.015)

    def open_servo_nine(self):
        for i in range(0, 90):
            self.board.digital[9].write(i)
            sleep(0.015)

    def close_servo_nine(self):
        for i in range(90, 1, -1):
            self.board.digital[9].write(i)
            sleep(0.015)

    def open_servo_five(self):
        for i in range(90, 1, -1):
            self.board.digital[5].write(i)
            sleep(0.015)

    def close_servo_five(self):
        for i in range(0, 90):
            self.board.digital[5].write(i)
            sleep(0.015)

    def open_servo_six(self):
        for i in range(90, 1, -1):
            self.board.digital[6].write(i)
            sleep(0.015)

    def close_servo_six(self):
        for i in range(0, 90):
            self.board.digital[6].write(i)
            sleep(0.015)

servo_3 = Servo(3)
servo_5 = Servo(5)
servo_6 = Servo(6)
servo_9 = Servo(9)

t3_o = threading.Thread(target=servo_3.open_servo_three)
t3_c = threading.Thread(target=servo_3.close_servo_three)
t5_o = threading.Thread(target=servo_5.open_servo_five)
t5_c = threading.Thread(target=servo_5.close_servo_five)
t6_o = threading.Thread(target=servo_6.open_servo_six)
t6_c = threading.Thread(target=servo_6.close_servo_six)
t9_o = threading.Thread(target=servo_9.open_servo_nine)
t9_c = threading.Thread(target=servo_9.close_servo_nine)

def OpenServoThree():
    t3_o.start()
    t3_o.join()

def CloseServoThree():
    t3_c.start()
    t3_c.join()

def OpenServoFive():
    t5_o.start()
    t5_o.join()

def CloseServoFive():
    t5_c.start()
    t5_c.join()

def OpenServoSix():
    t6_o.start()
    t6_o.join()

def CloseServoSix():
    t6_c.start()
    t6_c.join()

def OpenServoNine():
    t9_o.start()
    t9_o.join()

def CloseServoNine():
    t9_c.start()
    t9_c.join()