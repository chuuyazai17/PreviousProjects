import sqlite3
import datetime
from sqlite3 import Error
from datetime import datetime
from kink import inject, di

from ImmerVerloren.dto import AccountDTO, DepositDTO, LockerDTO


@inject
class Connectors:
    def __init__(self, db_file):
        self.file_database = db_file

    def create_connection(self):
        conn_1 = None
        try:
            conn_1 = sqlite3.connect(self.file_database)
            return conn_1
        except Error as e:
            print(e)
        return conn_1


@inject
class ImmerVerlorenRepository:
    def __init__(self, db_file, db_init: str = "False"):
        connection = Connectors(db_file).create_connection()
        self.conn = connection
        self.c = self.conn.cursor()
        self.db_init = db_init

        self.__operator_id = "admin"
        self.__operator_password = "admin"

    def __drop_table(self):
        def drop_table_users():
            table_users = """
                DROP TABLE users
            """
            self.c.execute(table_users)
            self.conn.commit()

        def drop_table_locker():
            table_locker = """
                DROP TABLE locker
            """
            self.c.execute(table_locker)
            self.conn.commit()

        def drop_table_deposit():
            table_deposit = """
                DROP TABLE deposit
            """
            self.c.execute(table_deposit)
            self.conn.commit()

        drop_table_users()
        drop_table_locker()
        drop_table_deposit()

    def __create_table(self):
        def create_table_users():
            table_users = """
                CREATE TABLE users(
                      id_user    INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_name    TEXT NOT NULL,
                   user_email    TEXT NOT NULL,
                     password    TEXT NOT NULL,
                          nim    TEXT DEFAULT NULL
                );
            """
            self.c.execute(table_users)
            self.conn.commit()

        def create_table_locker():
            table_locker = """
                CREATE TABLE locker(
                   no_locker    INTEGER PRIMARY KEY,
                        size    TEXT,
                      status    TEXT
                );
            """
            self.c.execute(table_locker)
            self.conn.commit()

        def create_table_deposit():
            table_deposit = """
                CREATE TABLE deposit(
                    id_deposit    INTEGER PRIMARY KEY AUTOINCREMENT,
                       id_user    INTEGER,
                     no_locker    INTEGER,
                    goods_type    TEXT NOT NULL,
                      finished    BIT (1),
                      time_put    DATETIME,
                     time_take    DATETIME,
                      FOREIGN KEY(id_user) REFERENCES users(id_user),
                      FOREIGN KEY(no_locker) REFERENCES locker(no_locker)
                );
            """
            self.c.execute(table_deposit)
            self.conn.commit()

        def insert_dummy_data_users():
            create_users = """
                INSERT INTO users(id_user, user_name, user_email, password, nim) 
                    values(10000, "dummy_user", "dummy_email@gmail.com", "dummy_password", -1);
                """
            self.c.execute(create_users)
            self.conn.commit()

        def insert_dummy_data_deposit():
            create_deposit = """
                INSERT INTO deposit(id_deposit, id_user, no_locker, goods_type, finished) 
                    values(1, 10000, 1, "dummy_package", 0);
            """
            self.c.execute(create_deposit)
            self.conn.commit()

        def insert_locker_data():
            create_locker_1 = """
                INSERT INTO locker(no_locker, size, status) 
                VALUES (1, "Big", "Available");
            """
            create_locker_2 = """
            INSERT INTO locker(no_locker, size, status) 
                VALUES (2, "Medium", "Available");
            """
            create_locker_3 = """
                INSERT INTO locker(no_locker, size, status) 
                VALUES (3, "Small", "Available");
            """

            create_locker_4 = """
                INSERT INTO locker(no_locker, size, status) 
                VALUES (4, "Small", "Available");
            """
            self.c.execute(create_locker_1)
            self.c.execute(create_locker_2)
            self.c.execute(create_locker_3)
            self.c.execute(create_locker_4)
            self.conn.commit()

        create_table_users()
        create_table_locker()
        create_table_deposit()

        insert_dummy_data_users()
        insert_dummy_data_deposit()
        insert_locker_data()

    def initialize(self):
        if self.db_init == "True":
            self.__drop_table()
            self.__create_table()
        elif self.db_init == "False":
            pass
        elif self.db_init == "Demo":
            pass  # under construction
        else:
            raise SystemError(f'db_init "{self.db_init}" is not recognize in our system!')

        return self.db_init

    def get_operator_id(self):
        return self.__operator_id

    def get_operator_password(self):
        return self.__operator_password

    def add_goods(self, id_user, no_locker, goods_type):
        now = datetime.now()
        current_time = now.strftime('%Y-%m-%d %H:%M:%S')
        finished = 0
        time_take = None

        add_goods = """
            INSERT INTO deposit(
                 id_user, no_locker, goods_type, finished, time_put, time_take
            )
            VALUES(?, ?, ?, ?, ?, ?)

        """
        self.c.execute(add_goods, (id_user, no_locker, goods_type, finished, current_time, time_take,))
        self.conn.commit()

    def change_locker_status_full(self, no_locker):
        change_status = """UPDATE locker
            SET status = 'Full'
            WHERE no_locker = ?
            """
        self.c.execute(change_status, (no_locker,))
        self.conn.commit()

    def remove_goods(self, no_locker):
        now = datetime.now()
        current_time = now.strftime('%Y-%m-%d %H:%M:%S')

        remove_goods = """
            UPDATE deposit
               SET finished = 1,
                  time_take = ?
             WHERE no_locker = ? 
        """
        self.c.execute(remove_goods, (current_time, no_locker,))
        self.conn.commit()

    def change_locker_status_available(self, no_locker):
        change_status = """
            UPDATE locker
            set status = 'Available'
            WHERE no_locker = ?
        """
        self.c.execute(change_status, (no_locker,))
        self.conn.commit()

    def get_all_deposit(self):
        select_all_deposit = """
            SELECT * FROM deposit
        """
        self.c.execute(select_all_deposit)
        rows = self.c.fetchall()

        returned_dto = []
        for i in rows:
            deposit = DepositDTO(i[0], i[1], i[2], i[3], i[4], i[5], i[6])
            returned_dto.append(deposit)

        return returned_dto

    def view_user_orders(self, user_id):
        user_orders = """
                SELECT deposit.no_locker, deposit.goods_type
                FROM deposit
                WHERE id_user = ?
                AND finished = 0
        """

        self.c.execute(user_orders, (user_id,))

        rows = self.c.fetchall()

        return rows

    def view_users_orders_only_lockers(self, user_id):
        locker_user_order = """
            SELECT no_locker
            FROM deposit
            WHERE id_user = ?
            AND finished = 0
        """

        self.c.execute(locker_user_order, (user_id,))
        lockers = self.c.fetchall()
        return lockers

    def get_all_accounts(self):
        select_all_account = """
            SELECT * from users
        """
        self.c.execute(select_all_account)
        rows = self.c.fetchall()

        returned_dto = []
        for i in rows:
            account = AccountDTO(i[0], i[1], i[2], i[3], i[4])
            returned_dto.append(account)

        return returned_dto

    def get_all_lockers(self):
        select_all_lockers = """
            SELECT * from locker
        """
        self.c.execute(select_all_lockers)
        rows = self.c.fetchall()

        returned_dto = []
        for i in rows:
            lockers = LockerDTO(i[0], i[1])
            returned_dto.append(lockers)

        return returned_dto

    def get_id_user_from_name(self, name):
        find_id_user = """
            SELECT id_user
            FROM users
            WHERE user_name = ?
        """
        self.c.execute(find_id_user, (name,))
        return self.c.fetchall()

    def find_id_user(self, id_num):
        find_id = """
            SELECT id_user
            FROM users
            WHERE id_user = ?
        """
        self.c.execute(find_id, (id_num,))
        return self.c.fetchall()

    def find_id_user_and_password(self, id_num, password):
        find_id = """
            SELECT users.id_user, users.password
                FROM users
                WHERE id_user = ?
                AND password = ?
        """
        self.c.execute(find_id, (id_num, password))
        return self.c.fetchall()

    def find_email(self, email):
        find_email = """
            SELECT user_email
                FROM users
                WHERE user_email = ?
        """
        self.c.execute(find_email, (email,))
        return self.c.fetchall()

    def find_nim(self, nim):
        find_nim = """
            SELECT users.nim
            FROM users
            WHERE nim = ?
        """
        self.c.execute(find_nim, (nim,))
        return self.c.fetchall()

    def create_account(self, user_name, user_email, password, nim):
        add_account_to_repo = """
            INSERT INTO users(
                 user_name, user_email, password, nim
            )
            values( ?, ?, ?, ?)
        """
        self.c.execute(add_account_to_repo, (user_name, user_email, password, nim,))
        self.conn.commit()

    def delete_account(self, id_num):
        delete_account_from_repo = """
            DELETE FROM users
                WHERE id_user = ?
        """
        self.c.execute(delete_account_from_repo, (id_num,))
        self.conn.commit()

    def time_diff(self):
        time_diff = """
            SELECT round(julianday(deposit.time_take) - julianday(deposit.time_put)) FROM deposit;
        """
        self.c.execute(time_diff)
        rows = self.c.fetchall()
        return rows

    def get_filled_locker(self):
        filled_locker = """
            SELECT COUNT(finished)
            FROM deposit
            WHERE finished = 1
        """
        self.c.execute(filled_locker)
        return self.c.fetchall()

    def get_unfinished_lockers(self, no_locker):
        unfinished_locker = """
            SELECT locker.no_locker
            FROM locker
            WHERE locker.no_locker = ?
            AND locker.status = "Full"
        """
        self.c.execute(unfinished_locker, (no_locker,))
        return self.c.fetchall()

    def user_query(self):
        user_query = """
            SELECT users
            FROM users
        """
        self.c.execute(user_query)
        self.conn.commit()
        return self.c.fetchall()

    def duration_per_item_type_query(self):
        duration_per_item_type_query = """
            SELECT deposit.goods_type, round(julianday(deposit.time_take) - julianday(deposit.time_put)) as duration
            FROM deposit
            GROUP BY goods_type
        """
        self.c.execute(duration_per_item_type_query)
        self.conn.commit()
        rows = self.c.fetchall()
        return rows

    def duration_per_item_size_query(self):
        duration_per_item_size_query = """
            SELECT round(julianday(deposit.time_take) - julianday(deposit.time_put)) as duration
            FROM deposit
            INNER JOIN locker
            ON deposit.no_locker == locker.no_locker
            GROUP BY locker.size
        """
        self.c.execute(duration_per_item_size_query)
        self.conn.commit()
        return self.c.fetchall()

    def duration_per_item_size(self):
        duration_per_item_size_and_type_query = """
                    SELECT locker.size, round(julianday(deposit.time_take) - julianday(deposit.time_put)) as duration
                    FROM deposit
                    INNER JOIN locker
                    ON deposit.no_locker == locker.no_locker
                    GROUP BY locker.size
                """
        self.c.execute(duration_per_item_size_and_type_query)
        self.conn.commit()
        return self.c.fetchall()

    def get_all_user(self):
        get_all_user = """
            SELECT * from users
        """
        self.c.execute(get_all_user)
        return self.c.fetchall()


if __name__ == '__main__':
    database = r"schliessfach_demo_database"
    di["db_file"] = database
    di["db_init"] = "False"
    repo = ImmerVerlorenRepository()
    print(repo.get_all_user())