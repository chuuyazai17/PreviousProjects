<header>
    <link rel="stylesheet" href="css/style.css"> 
    <div class="header">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <div class="flex">
        <!--<a href="products.php"class="header">LOGO</a>-->
        <nav class="navbar">
            <a href="products.php">View Products</a>
            <a href="index.php">Edit Product</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars"></div> 
    </div>
    </div>
</header>