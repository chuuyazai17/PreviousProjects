<?php

$conn = mysqli_connect('localhost','gloriamn','YkI6v3t7z3','gloriamn_website') or die('connection failed');

?>