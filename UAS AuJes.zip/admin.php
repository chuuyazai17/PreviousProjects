<?php

@include 'config.php';

if ( isset( $_POST[ 'add_product' ] ) ) {
  $p_id = $_POST[ 'p_id' ];
  $p_variant = $_POST[ 'p_variant' ];
  $p_weight = $_POST[ 'p_weight' ];
  $p_box_price = $_POST[ 'p_box_price' ];
  $p_pcs_price = $_POST[ 'p_pcs_price' ];
  $p_image = $_FILES[ 'p_image' ][ 'name' ];
  $p_image_tmp_name = $_FILES[ 'p_image' ][ 'tmp_name' ];
  $p_image_folder = 'uploaded_img/' . $p_image;

  $insert_query = mysqli_query( $conn, "INSERT INTO `products`(`product_id`, `varian`, `berat_bersih`, `harga_box`, `harga_pcs`, `gambar_produk`) VALUES ('$p_id','$p_variant', '$p_weight', '$p_box_price', '$p_pcs_price', '$p_image')" )or die( 'query failed' );


  if ( $insert_query ) {
    move_uploaded_file( $p_image_tmp_name, $p_image_folder );
    $message[] = 'product add succesfully';
  } else {
    $message[] = 'could not add the product';
  };
};

if ( isset( $_GET[ 'delete' ] ) ) {
  $delete_id = $_GET[ 'delete' ];
  $delete_query = mysqli_query( $conn, "DELETE FROM `products` WHERE product_id = $delete_id " )or die( 'query failed' );
  if ( $delete_query ) {
    header( 'location:admin.php' );
    $message[] = 'product has been deleted';
  } else {
    header( 'location:admin.php' );
    $message[] = 'product could not be deleted';
  };
};

if(isset($_POST['update_product'])){
   $update_p_id = $_POST['update_p_id'];
   $update_varian = $_POST['update_varian'];
   $update_weight = $_POST['update_weight'];
   $update_box_price = $_POST['update_box_price'];
   $update_pcs_price = $_POST['update_pcs_price'];
   $update_p_image = $_FILES['update_p_image']['name'];
   $update_p_image_tmp_name = $_FILES['update_p_image']['tmp_name'];
   $update_p_image_folder = 'uploaded_img/'.$update_p_image;

   $update_query = mysqli_query($conn, "UPDATE `products` SET varian = '$update_varian', berat_bersih = '$update_weight', harga_box = '$update_box_price', harga_pcs ='$update_pcs_price', gambar_produk = '$update_p_image' WHERE product_id = '$update_p_id'");

   if($update_query){
      move_uploaded_file($update_p_image_tmp_name, $update_p_image_folder);
      $message[] = 'product updated succesfully';
      header('location:admin.php');
   }else{
      $message[] = 'product could not be updated';
      header('location:admin.php');
   }

}

?>

<!doctype html>
<html>
<head>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE-edge">
<meta name-"viewport" content="width=device-width, initial-scale=1.0">
<title>Panel Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php

if ( isset( $message ) ) {
  foreach ( $message as $message ) {
    echo '<div class="message"><span>' . $message . '</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i></div>';
  };
};

?>
<?php include 'header.php'; ?>
<div class="container">
  <section>
    <form action="" method="post" class="add-product-form" enctype="multipart/form-data">
      <h3>Menambahkan Produk Baru</h3>
      <input type="text" name="p_id" placeholder="ID produk" class="box" required>
      <input type="text" name="p_variant" placeholder="Varian produk" class="box" required>
      <input type="text" name="p_weight" placeholder="Berat bersih produk" class="box" required>
      <input type="text" name="p_box_price" placeholder="Harga per box produk" class="box" required>
      <input type="text" name="p_pcs_price" placeholder="Harga per pcs produk" class="box" required>
      <input type="file" name="p_image" accept="image/png, image/jpg, image/jpeg" class="box" required>
      <input type="submit" value="Tambahkan Produk" name="add_product" class="btn">
    </form>
  </section>
  <section class="display-product-table">
    <table>
      <thead>
      <th>Gambar Produk</th>
        <th>ID Produk</th>
        <th>Varian Produk</th>
        <th>Berat Bersih</th>
        <th>Harga Box</th>
        <th>Harga Pcs</th>
        </thead>
      <tbody>
        <?php

        $select_products = mysqli_query( $conn, "SELECT * FROM `products`" );
        if ( mysqli_num_rows( $select_products ) > 0 ) {
          while ( $row = mysqli_fetch_assoc( $select_products ) ) {
            ?>
        <tr>
          <td><img src="uploaded_img/<?php echo $row['gambar_produk']; ?>" height="100" alt=""></td>
          <td><?php echo $row['product_id']; ?></td>
          <td><?php echo $row['varian']; ?></td>
          <td><?php echo $row['berat_bersih']; ?></td>
          <td>Rp <?php echo $row['harga_box']; ?>,00</td>
          <td>Rp <?php echo $row['harga_pcs']; ?>,00</td>
          <td><a href="admin.php?delete=<?php echo $row['product_id']; ?>" class="delete-btn" onclick="return confirm('are your sure you want to delete this?');"> <i class="fas fa-trash"></i> delete </a> <a href="admin.php?edit=<?php echo $row['product_id']; ?>" class="option-btn"> <i class="fas fa-edit"></i> update </a></td>
        </tr>
        <?php
        };
        } else {
          echo "<span>no product added</span>";
        };
        ?>
      </tbody>
    </table>
  </section>
  
<section class="edit-form-container">

   <?php
   
   if(isset($_GET['edit'])){
      $edit_id = $_GET['edit'];
      $edit_query = mysqli_query($conn, "SELECT * FROM `products` WHERE product_id = $edit_id");
      if(mysqli_num_rows($edit_query) > 0){
         while($fetch_edit = mysqli_fetch_assoc($edit_query)){
   ?>

   <form action="" method="post" enctype="multipart/form-data">
      <img src="uploaded_img/<?php echo $fetch_edit['gambar_produk']; ?>" height="200" alt="">
      <input type="hidden" name="update_p_id" value="<?php echo $fetch_edit['product_id']; ?>">
      <input type="text" class="box" required name="update_varian" value="<?php echo $fetch_edit['varian']; ?>">
      <input type="text" class="box" required name="update_weight" value="<?php echo $fetch_edit['berat_bersih']; ?>">
      <input type="number" min="0" class="box" required name="update_box_price" value="<?php echo $fetch_edit['harga_box']; ?>">
      <input type="number" min="0" class="box" required name="update_pcs_price" value="<?php echo $fetch_edit['harga_pcs']; ?>">
      <input type="file" class="box" required name="update_p_image" accept="image/png, image/jpg, image/jpeg">
      <input type="submit" value="update the product" name="update_product" class="btn">
      <input type="reset" value="cancel" id="close_edit" class="option-btn">
   </form>

   <?php
            };
         };
         echo "<script>document.querySelector('.edit-form-container').style.display = 'flex';</script>";
      };
   ?>

</section>
</div>
<script src="js/script.js"></script>
</body>
</html>